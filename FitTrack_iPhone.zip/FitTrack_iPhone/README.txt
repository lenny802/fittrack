FitTrack – iPhone-App-Projekt (SwiftUI)

Enthalten:
- 5-Tage-Split: Schultern + Trizeps, Brust + Bizeps, Rücken + Trizeps, Bauch und Beine
- Gewicht, Wiederholungen und Satznummer eintragen
- Trainingshistorie
- Lokale Speicherung auf dem iPhone
- Dunkles Design

So startest du die App:
1. Auf einem Mac Xcode aus dem Mac App Store installieren.
2. Xcode öffnen und File > New > Project > iOS > App auswählen.
3. Produktname: FitTrack; Interface: SwiftUI; Language: Swift.
4. Den Inhalt der automatisch erstellten App-Datei durch FitTrackApp.swift aus diesem Paket ersetzen.
5. Unter Signing & Capabilities ein eigenes Team auswählen (mit deiner Apple-ID anmelden).
6. Ein iPhone anschließen oder einen iPhone-Simulator wählen und auf Run (▶) drücken.

Hinweis: Dies ist SwiftUI-Quellcode, kein bereits signiertes App-Store-Installationspaket. Für die Veröffentlichung im App Store sind weitere Einrichtung und Apples Prüfprozess nötig.
