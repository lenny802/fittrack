import SwiftUI

struct Exercise: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var sets: Int
    var repRange: String
}
struct SetEntry: Identifiable, Codable {
    var id = UUID()
    var date: Date
    var day: String
    var exercise: String
    var setNumber: Int
    var weight: Double
    var reps: Int
}
struct WorkoutDay: Identifiable {
    var id: String { name }
    let name: String
    let exercises: [Exercise]
}
let workoutDays: [WorkoutDay] = [
    WorkoutDay(name: "Schultern + Trizeps", exercises: [
        Exercise(name: "Schulterdrücken mit Kurzhanteln", sets: 3, repRange: "8–12"),
        Exercise(name: "Seitheben", sets: 3, repRange: "12–15"),
        Exercise(name: "Reverse Flys", sets: 3, repRange: "12–15"),
        Exercise(name: "Trizepsdrücken am Kabel", sets: 3, repRange: "10–15"),
        Exercise(name: "Trizepsstrecken über Kopf", sets: 2, repRange: "10–15")
    ]),
    WorkoutDay(name: "Brust + Bizeps", exercises: [
        Exercise(name: "Bankdrücken", sets: 3, repRange: "8–12"),
        Exercise(name: "Schrägbankdrücken", sets: 3, repRange: "8–12"),
        Exercise(name: "Butterfly", sets: 2, repRange: "12–15"),
        Exercise(name: "Bizepscurls", sets: 3, repRange: "10–12"),
        Exercise(name: "Hammercurls", sets: 2, repRange: "10–12")
    ]),
    WorkoutDay(name: "Rücken + Trizeps", exercises: [
        Exercise(name: "Latzug", sets: 3, repRange: "8–12"),
        Exercise(name: "Rudern am Kabel", sets: 3, repRange: "8–12"),
        Exercise(name: "Brustgestütztes Rudern", sets: 2, repRange: "10–12"),
        Exercise(name: "Trizepsdrücken am Kabel", sets: 3, repRange: "10–15")
    ]),
    WorkoutDay(name: "Bauch", exercises: [
        Exercise(name: "Crunches", sets: 3, repRange: "12–15"),
        Exercise(name: "Reverse Crunches", sets: 3, repRange: "10–15"),
        Exercise(name: "Plank", sets: 3, repRange: "30–45 Sek."),
        Exercise(name: "Dead Bug", sets: 2, repRange: "10 pro Seite")
    ]),
    WorkoutDay(name: "Beine", exercises: [
        Exercise(name: "Beinpresse", sets: 3, repRange: "10–12"),
        Exercise(name: "Beinbeuger", sets: 3, repRange: "10–15"),
        Exercise(name: "Beinstrecker", sets: 3, repRange: "10–15"),
        Exercise(name: "Wadenheben", sets: 3, repRange: "12–15"),
        Exercise(name: "Glute Bridge", sets: 2, repRange: "12")
    ])
]

@MainActor final class WorkoutStore: ObservableObject {
    @Published var entries: [SetEntry] = [] { didSet { save() } }
    private let key = "fittrack.entries.v1"
    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([SetEntry].self, from: data) { entries = saved }
    }
    private func save() {
        if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: key) }
    }
    func add(day: String, exercise: String, setNumber: Int, weight: Double, reps: Int) {
        entries.append(SetEntry(date: .now, day: day, exercise: exercise, setNumber: setNumber, weight: weight, reps: reps))
    }
    func remove(_ entry: SetEntry) { entries.removeAll { $0.id == entry.id } }
}

@main struct FitTrackApp: App {
    @StateObject private var store = WorkoutStore()
    var body: some Scene {
        WindowGroup { HomeView().environmentObject(store).preferredColorScheme(.dark) }
    }
}
struct HomeView: View {
    @EnvironmentObject var store: WorkoutStore
    var body: some View {
        TabView {
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        Label("FitTrack", systemImage: "dumbbell.fill").font(.largeTitle.bold()).foregroundStyle(.blue)
                        Text("Dein Training. Dein Fortschritt.").foregroundStyle(.secondary)
                        Label("Ziel: Muskelaufbau", systemImage: "scope").font(.headline)
                            .padding().frame(maxWidth: .infinity, alignment: .leading)
                            .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
                        Text("Dein 5-Tage-Split").font(.title2.bold())
                        ForEach(workoutDays) { day in
                            NavigationLink { DayView(day: day) } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(day.name).font(.headline)
                                    Text("\(day.exercises.count) Übungen").font(.subheadline).foregroundStyle(.secondary)
                                }.frame(maxWidth: .infinity, alignment: .leading).padding()
                                    .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
                            }.buttonStyle(.plain)
                        }
                        Text("Gespeicherte Sätze: \(store.entries.count)").font(.headline).padding(.top, 8)
                    }.padding()
                }.background(Color(red: 0.025, green: 0.045, blue: 0.075))
                    .navigationTitle("Start")
            }.tabItem { Label("Start", systemImage: "house.fill") }
            NavigationStack { PlanView() }.tabItem { Label("Training", systemImage: "dumbbell.fill") }
            NavigationStack { HistoryView() }.tabItem { Label("Verlauf", systemImage: "chart.bar.fill") }
        }.tint(.blue)
    }
}
struct PlanView: View {
    var body: some View {
        List {
            ForEach(workoutDays) { day in
                NavigationLink { DayView(day: day) } label: {
                    VStack(alignment: .leading) {
                        Text(day.name).font(.headline)
                        Text("\(day.exercises.count) Übungen").font(.caption).foregroundStyle(.secondary)
                    }.padding(.vertical, 4)
                }
            }
        }.navigationTitle("Trainingsplan")
    }
}
struct DayView: View {
    @EnvironmentObject var store: WorkoutStore
    let day: WorkoutDay
    var body: some View {
        List {
            ForEach(day.exercises) { exercise in
                NavigationLink { ExerciseView(day: day, exercise: exercise) } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(exercise.name).font(.headline)
                        Text("\(exercise.sets) Sätze · \(exercise.repRange) Wiederholungen").font(.subheadline).foregroundStyle(.secondary)
                        let count = store.entries.filter { $0.day == day.name && $0.exercise == exercise.name }.count
                        if count > 0 { Text("\(count) Sätze eingetragen").font(.caption).foregroundStyle(.green) }
                    }.padding(.vertical, 4)
                }
            }
        }.navigationTitle(day.name).navigationBarTitleDisplayMode(.inline)
    }
}
struct ExerciseView: View {
    @EnvironmentObject var store: WorkoutStore
    let day: WorkoutDay
    let exercise: Exercise
    @State private var setNumber = 1
    @State private var weight = "10"
    @State private var reps = "10"
    @State private var savedMessage = false
    private var prior: [SetEntry] { store.entries.filter { $0.day == day.name && $0.exercise == exercise.name }.sorted { $0.date > $1.date } }
    var body: some View {
        Form {
            Section("Übung") {
                Text(exercise.name).font(.headline)
                LabeledContent("Zielsätze", value: "\(exercise.sets)")
                LabeledContent("Wiederholungen", value: exercise.repRange)
            }
            Section("Satz eintragen") {
                Picker("Satznummer", selection: $setNumber) {
                    ForEach(1...exercise.sets, id: \.self) { Text("Satz \($0)").tag($0) }
                }.pickerStyle(.segmented)
                HStack {
                    Text("Gewicht (kg)")
                    Spacer()
                    TextField("10", text: $weight).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(width: 90)
                }
                HStack {
                    Text("Wiederholungen")
                    Spacer()
                    TextField("10", text: $reps).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 90)
                }
                Button {
                    if let w = Double(weight.replacingOccurrences(of: ",", with: ".")),
                       let r = Int(reps), w >= 0, r > 0 {
                        store.add(day: day.name, exercise: exercise.name, setNumber: setNumber, weight: w, reps: r)
                        savedMessage = true
                        if setNumber < exercise.sets { setNumber += 1 }
                    }
                } label: { Label("Satz speichern", systemImage: "checkmark.circle.fill") }
                if savedMessage { Text("Satz gespeichert!").foregroundStyle(.green) }
            }
            if !prior.isEmpty {
                Section("Bisherige Einträge") {
                    ForEach(prior) { entry in
                        HStack {
                            VStack(alignment: .leading) {
                                Text("Satz \(entry.setNumber): \(entry.weight.formatted()) kg × \(entry.reps)")
                                Text(entry.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button(role: .destructive) { store.remove(entry) } label: { Image(systemName: "trash") }
                        }
                    }
                }
            }
        }.navigationTitle("Satz eintragen").navigationBarTitleDisplayMode(.inline)
    }
}
struct HistoryView: View {
    @EnvironmentObject var store: WorkoutStore
    private var sorted: [SetEntry] { store.entries.sorted { $0.date > $1.date } }
    var body: some View {
        List {
            Section {
                Text("Gespeicherte Sätze: \(store.entries.count)").font(.title2.bold())
            }
            Section("Trainingsverlauf") {
                if sorted.isEmpty {
                    ContentUnavailableView("Noch kein Training", systemImage: "chart.bar", description: Text("Deine gespeicherten Sätze erscheinen hier."))
                } else {
                    ForEach(sorted) { entry in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(entry.exercise).font(.headline)
                            Text("\(entry.day) · Satz \(entry.setNumber)").font(.subheadline).foregroundStyle(.secondary)
                            Text("\(entry.weight.formatted()) kg × \(entry.reps) Wiederholungen").foregroundStyle(.blue)
                            Text(entry.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 3)
                    }.onDelete { offsets in offsets.map { sorted[$0] }.forEach { store.remove($0) } }
                }
            }
        }.navigationTitle("Fortschritt")
    }
}
